import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { TOOLS } from '../src/data/tools.js';

// Read VITE_SITE_URL from .env (if present) or the environment.
let siteUrl = process.env.VITE_SITE_URL || '';
if (!siteUrl && existsSync('.env')) {
  const line = readFileSync('.env', 'utf8').split('\n').find((l) => l.startsWith('VITE_SITE_URL='));
  if (line) siteUrl = line.split('=')[1].trim();
}
siteUrl = siteUrl.replace(/\/$/, '');

if (!siteUrl || siteUrl.includes('yourdomain.com')) {
  console.warn('[sitemap] VITE_SITE_URL is not set to your real domain. Set it in .env before deploying.');
}

const staticPaths = ['/', '/tools', '/about', '/contact', '/privacy', '/terms', '/disclaimer'];
const paths = [...staticPaths, ...TOOLS.map((t) => `/tools/${t.slug}`)];
const today = new Date().toISOString().slice(0, 10);

const urls = paths
  .map((p) => `  <url>\n    <loc>${siteUrl}${p}</loc>\n    <lastmod>${today}</lastmod>\n  </url>`)
  .join('\n');

writeFileSync(
  'public/sitemap.xml',
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`
);

writeFileSync(
  'public/robots.txt',
  `User-agent: *\nAllow: /\n\nSitemap: ${siteUrl}/sitemap.xml\n`
);

console.log(`[sitemap] wrote ${paths.length} URLs for ${siteUrl || '(no site URL set)'}`);
