// Post-build step: writes one HTML file per route into dist/ with route-specific
// <title>, description, canonical and Open Graph tags. Crawlers and social previews
// read these files directly, without running JavaScript. Dependency-free.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { TOOLS } from '../src/data/tools.js';
import { PAGES_SEO } from '../src/data/pagesSeo.js';

const DIST = 'dist';
if (!existsSync(join(DIST, 'index.html'))) {
  console.error('[prerender] dist/index.html not found. Run vite build first.');
  process.exit(1);
}

function readEnv(key) {
  if (!existsSync('.env')) return '';
  const line = readFileSync('.env', 'utf8').split('\n').find((l) => l.startsWith(key + '='));
  return line ? line.slice(key.length + 1).trim() : '';
}
const site = (process.env.VITE_SITE_URL || readEnv('VITE_SITE_URL')).replace(/\/$/, '');
if (!site || site.includes('yourdomain.com')) {
  console.warn('[prerender] VITE_SITE_URL is not set to your real domain; canonical URLs will be relative.');
}

const template = readFileSync(join(DIST, 'index.html'), 'utf8');
const esc = (s) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');

const routes = [
  ...PAGES_SEO,
  ...TOOLS.map((t) => ({ path: `/tools/${t.slug}`, title: t.seoTitle, description: t.seoDescription })),
];

for (const r of routes) {
  const url = site + r.path;
  const head = [
    `<link rel="canonical" href="${esc(url)}" />`,
    `<meta property="og:title" content="${esc(r.title)}" />`,
    `<meta property="og:description" content="${esc(r.description)}" />`,
    `<meta property="og:type" content="website" />`,
    `<meta property="og:url" content="${esc(url)}" />`,
    `<meta name="twitter:card" content="summary" />`,
  ].join('\n    ');
  const html = template
    .replace(/<title>[\s\S]*?<\/title>/, `<title>${esc(r.title)}</title>`)
    .replace(/<meta name="description"[^>]*>/, `<meta name="description" content="${esc(r.description)}" />`)
    .replace('</head>', `    ${head}\n  </head>`);
  const out = r.path === '/' ? join(DIST, 'index.html') : join(DIST, r.path.slice(1), 'index.html');
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, html);
}
console.log(`[prerender] wrote ${routes.length} route files`);
