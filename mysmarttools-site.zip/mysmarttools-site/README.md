# MySmartTools

Free online calculators and everyday tools built with Vite and React. Tools run in the visitor's browser: no accounts, no payments, no uploads of user files.

## What is included

20 working tools, each with its own URL (`/tools/<slug>`):

| Category | Tools |
|---|---|
| Calculators | Age, EMI, GST, Percentage, Discount, Simple Interest, Compound Interest, BMI |
| Image tools | Image Compressor, Image Resizer, Image Converter (JPG, PNG, WEBP) |
| Everyday tools | QR Code Generator, Word Counter, Case Converter, Password Generator, Unit Converter, Date Calculator, Time Calculator, Text to Speech, Resume Builder |

Pages: Home, Tools directory, About Us, Contact Us, Privacy Policy, Terms and Conditions, Disclaimer, 404.

Languages: English, Hindi (हिन्दी) and Gujarati (ગુજરાતી), switchable in the header. The choice is saved in the browser.

## 1. Requirements

- Node.js 18 or newer (Node 22 was used to test the build scripts)
- npm (included with Node.js)
- A GitHub account (for the hosting steps in section 5)

## 2. Install and run locally

```bash
cd mysmarttools-site
npm install
cp .env.example .env       # Windows: copy .env.example .env
npm run dev                # open http://localhost:5173
```

`npm install` downloads React, Vite, React Router and the `qrcode` library (used only by the QR code tool). The only npm package that runs in the browser beyond React is `qrcode`.

## 3. Configure your domain, contact email and ads

Edit `.env`:

| Variable | Required before launch | What it does |
|---|---|---|
| `VITE_SITE_URL` | Yes | Your live address, for example `https://www.yourdomain.com`. Used for canonical links, sitemap, robots.txt and prerendered pages. |
| `VITE_CONTACT_EMAIL` | Yes | Mailbox shown on the Contact, Privacy and Terms pages. Must be an address you read. |
| `VITE_ADSENSE_CLIENT` | Only after AdSense approval | Your publisher ID, `ca-pub-XXXXXXXXXXXXXXXX`. |
| `VITE_ADSENSE_SLOT` | Only after AdSense approval | The ad unit ID you create in AdSense. |

`VITE_*` values are built into the site, so rebuild after changing them.

## 4. Build and check locally

```bash
npm run build              # sitemap + robots.txt, Vite build, then prerendering into dist/
npm run preview            # serves dist/ at http://localhost:4173
```

The build runs three steps:

1. `scripts/generate-sitemap.mjs` writes `public/sitemap.xml` and `public/robots.txt` with your `VITE_SITE_URL`.
2. `vite build` writes the app to `dist/`.
3. `scripts/prerender.mjs` writes one HTML file per route (for example `dist/tools/resume-builder/index.html`) with that page's own title, description, canonical link and Open Graph tags. Social previews and non-JavaScript crawlers read these files.

Before you deploy, check:

- `dist/robots.txt` and `dist/sitemap.xml` show your real domain (not `yourdomain.com`).
- `dist/tools/image-compressor/index.html` contains the right `<title>`.

## 5. Publish on Netlify (step by step)

These steps use Netlify's free plan. Vercel and Cloudflare Pages work the same way with the same build command and output folder.

1. **Put the code on GitHub.** Create an empty repository, then from the project folder run:
   ```bash
   git init
   git add .
   git commit -m "MySmartTools site"
   git branch -M main
   git remote add origin https://github.com/<your-user>/mysmarttools.git
   git push -u origin main
   ```
   `.env` is excluded by `.gitignore`. Do not commit it.
2. **Create the site.** In Netlify choose **Add new site → Import an existing project → GitHub**, and select the repository.
3. **Set build settings:**
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Node version: 18 or newer (set `NODE_VERSION = 22` under Environment variables if the build fails on an old default)
4. **Add environment variables** under **Site configuration → Environment variables**: `VITE_SITE_URL`, `VITE_CONTACT_EMAIL`, and later `VITE_ADSENSE_CLIENT` and `VITE_ADSENSE_SLOT`.
5. **Deploy.** Netlify gives you a `https://<name>.netlify.app` address. Open it and test a tool page, for example `/tools/emi-calculator`, and refresh the page.
6. **Routing.** `public/_redirects` contains `/*  /index.html  200`, so deep links work on Netlify. Keep this file.

## 6. Connect a custom domain

1. Buy a domain from a registrar (for example Namecheap, GoDaddy or Google Domains successor Squarespace Domains).
2. In Netlify go to **Domain management → Add a domain** and enter `yourdomain.com`.
3. At your registrar, add the DNS records Netlify shows. Typically:
   - `www` → CNAME → `<name>.netlify.app`
   - root domain (`@`) → A record → the IP address Netlify lists (or use Netlify DNS by changing nameservers as Netlify instructs).
4. Wait for DNS to propagate (minutes to a few hours). Netlify then issues a free HTTPS certificate automatically. Make sure HTTPS shows as active.
5. Set the primary domain in Netlify to `https://www.yourdomain.com` (or the root domain), matching `VITE_SITE_URL`. If you change `VITE_SITE_URL`, rebuild and redeploy.
6. Confirm these load: `https://www.yourdomain.com/`, `/tools/bmi-calculator`, `/robots.txt`, `/sitemap.xml`.

## 7. Submit to search engines

1. Go to Google Search Console, add the property `https://www.yourdomain.com`, and verify ownership (the DNS method is simplest).
2. Under **Sitemaps**, submit `sitemap.xml`.
3. Optionally submit the same sitemap to Bing Webmaster Tools.

## 8. Google AdSense

1. Deploy on your custom domain with real content. Confirm all policy pages load and the contact email works.
2. Apply at https://www.google.com/adsense. Add the verification code from AdSense to `index.html`, inside `<head>`, then redeploy.
3. After approval, create a responsive Display ad unit and copy the publisher ID and slot ID into the environment variables. Redeploy.
4. Ad areas appear only in production builds with both IDs set. They sit below tool panels and on the directory page, never inside inputs or buttons.
5. Never click your own ads or ask anyone else to click them.
6. Approval is not guaranteed. Read the policies at https://support.google.com/adsense/answer/48182 before applying.

## 9. Updating the site

Edit code, commit, and push to `main`. Netlify rebuilds automatically. To add a new tool: add an entry to `src/data/tools.js`, add a component to `src/tools/`, and register it in `src/tools/index.jsx` under the same slug.

## 10. Known limitations

- **Translations:** navigation, search, buttons, footer, tool names and tool descriptions are translated into Hindi and Gujarati. Tool input labels, result text, the policy pages and the in-page headings are still English. Translating these is the main open task.
- **Prerendered metadata is English only.** The prerendered titles and descriptions come from `src/data/tools.js` and `src/data/pagesSeo.js` (English). Keep those in sync with the page components when you edit copy.
- **Page bodies are not prerendered.** Only metadata is prerendered. Crawlers that do not run JavaScript see the titles and descriptions but not the tool UI text.
- **Browser support:** Text to Speech depends on voices installed on the device. Image WEBP output depends on the browser; Safari may save WEBP as PNG, and the converter then shows a message.
- **Resume Builder** saves through the browser's print dialog ("Save as PDF"). It does not produce a server-generated file.
- **No automated tests are included.** Test each tool and page on mobile and desktop before launch.
- **Legal text** on the Privacy Policy, Terms and Disclaimer is a starting draft. Have it reviewed for your jurisdiction before launch.
