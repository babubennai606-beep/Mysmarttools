import { useEffect } from 'react';

const CLIENT = import.meta.env.VITE_ADSENSE_CLIENT;
const SLOT = import.meta.env.VITE_ADSENSE_SLOT;

// Renders a labelled ad area only when AdSense IDs are configured. Never shows fake ads.
// Placed beside content (below tool panels and the directory), never inside tool inputs or buttons.
export default function AdSlot() {
  const enabled = Boolean(CLIENT && SLOT && import.meta.env.PROD);

  useEffect(() => {
    if (!enabled) return;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.warn('AdSense did not load:', e);
    }
  }, [enabled]);

  if (!enabled) return null;

  return (
    <aside className="ad" aria-label="Advertisement">
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client={CLIENT}
        data-ad-slot={SLOT}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </aside>
  );
}
