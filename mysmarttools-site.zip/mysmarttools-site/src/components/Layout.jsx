import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { LANGS, useI18n } from '../i18n.jsx';

const CONTACT_EMAIL = import.meta.env.VITE_CONTACT_EMAIL;

export default function Layout() {
  const { lang, setLang, t } = useI18n();
  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem('mst-theme');
      if (saved) return saved;
    } catch { /* ignore */ }
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('mst-theme', theme); } catch { /* ignore */ }
  }, [theme]);

  const links = [
    ['/', t.home], ['/tools', t.tools], ['/about', t.about], ['/contact', t.contact],
    ['/privacy', t.privacy], ['/terms', t.terms], ['/disclaimer', t.disclaimer],
  ];

  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <header className="site-header">
        <Link className="logo" to="/">My<span>Smart</span>Tools</Link>
        <nav aria-label="Main navigation" className="main-nav">
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === '/'}>{label}</NavLink>
          ))}
        </nav>
        <div className="controls">
          <label className="visually-hidden" htmlFor="lang-select">{t.language}</label>
          <select id="lang-select" value={lang} onChange={(e) => setLang(e.target.value)}>
            {LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
          </select>
          <button
            type="button"
            className="ghost"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            aria-label={theme === 'dark' ? t.light : t.dark}
          >
            {theme === 'dark' ? '☀' : '☾'}
          </button>
        </div>
      </header>

      <main id="main" className="container">
        <Outlet />
      </main>

      <footer className="site-footer">
        <nav aria-label="Footer navigation">
          {links.map(([to, label]) => <Link key={to} to={to}>{label}</Link>)}
        </nav>
        <p>{t.note}</p>
        <p>© {new Date().getFullYear()} MySmartTools. {t.footer}
          {CONTACT_EMAIL && <> · <a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></>}
        </p>
      </footer>
    </>
  );
}
