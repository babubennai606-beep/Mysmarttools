import { useEffect } from 'react';

const SITE = (import.meta.env.VITE_SITE_URL || '').replace(/\/$/, '');

function upsert(tag, keyAttr, key, attrs) {
  let el = document.head.querySelector(`${tag}[${keyAttr}="${key}"]`);
  if (!el) {
    el = document.createElement(tag);
    el.setAttribute(keyAttr, key);
    document.head.appendChild(el);
  }
  Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
}

// Sets per-page metadata on client-side navigation. For crawlers that do not run JavaScript,
// see the prerendering note in README.md.
export default function Seo({ title, description, path = '/' }) {
  useEffect(() => {
    document.title = title;
    upsert('meta', 'name', 'description', { content: description });
    upsert('meta', 'property', 'og:title', { content: title });
    upsert('meta', 'property', 'og:description', { content: description });
    upsert('meta', 'property', 'og:type', { content: 'website' });
    if (SITE) {
      const url = SITE + path;
      upsert('link', 'rel', 'canonical', { href: url });
      upsert('meta', 'property', 'og:url', { content: url });
    }
  }, [title, description, path]);
  return null;
}
