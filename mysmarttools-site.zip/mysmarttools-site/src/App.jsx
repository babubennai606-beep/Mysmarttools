import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import Directory from './pages/Directory.jsx';
import ToolPage from './pages/ToolPage.jsx';
import { About, Contact, Privacy, Terms, Disclaimer } from './pages/StaticPages.jsx';
import NotFound from './pages/NotFound.jsx';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Directory />} />
        <Route path="/tools" element={<Directory />} />
        <Route path="/tools/:slug" element={<ToolPage />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/disclaimer" element={<Disclaimer />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
