import { createContext, useContext, useEffect, useState } from 'react';

export const LANGS = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिन्दी' },
  { code: 'gu', label: 'ગુજરાતી' },
];

export const UI = {
  en: {
    tagline: 'Free online tools. No sign-up, no payment.',
    search: 'Search tools…',
    back: '← All tools',
    noResults: 'No tools match your search.',
    catCalc: 'Calculators',
    catUtil: 'Everyday tools',
    open: 'Open tool',
    home: 'Home', tools: 'Tools', about: 'About Us', contact: 'Contact Us',
    privacy: 'Privacy Policy', terms: 'Terms', disclaimer: 'Disclaimer',
    dark: 'Dark mode', light: 'Light mode', language: 'Language',
    note: 'Calculations run on your device. Nothing you enter is sent to our servers.',
    copy: 'Copy', copied: 'Copied!',
    footer: 'Free tools, no registration.',
    notFoundTitle: 'Page not found',
    notFoundText: 'This page does not exist. Browse the tools directory instead.',
    directory: 'All free tools',
  },
  hi: {
    tagline: 'मुफ़्त ऑनलाइन टूल्स। न साइन-अप, न भुगतान।',
    search: 'टूल खोजें…',
    back: '← सभी टूल्स',
    noResults: 'आपकी खोज से कोई टूल नहीं मिला।',
    catCalc: 'कैलकुलेटर',
    catUtil: 'रोज़ के उपयोगी टूल्स',
    open: 'टूल खोलें',
    home: 'होम', tools: 'टूल्स', about: 'हमारे बारे में', contact: 'संपर्क करें',
    privacy: 'गोपनीयता नीति', terms: 'नियम और शर्तें', disclaimer: 'अस्वीकरण',
    dark: 'डार्क मोड', light: 'लाइट मोड', language: 'भाषा',
    note: 'गणना आपके डिवाइस पर होती है। आपका दर्ज किया गया डेटा हमारे सर्वर पर नहीं भेजा जाता।',
    copy: 'कॉपी करें', copied: 'कॉपी हो गया!',
    footer: 'मुफ़्त टूल्स, बिना रजिस्ट्रेशन।',
    notFoundTitle: 'पेज नहीं मिला',
    notFoundText: 'यह पेज मौजूद नहीं है। टूल्स की सूची देखें।',
    directory: 'सभी मुफ़्त टूल्स',
  },
  gu: {
    tagline: 'મફત ઓનલાઇન ટૂલ્સ. સાઇન-અપ નહીં, ચુકવણી નહીં.',
    search: 'ટૂલ શોધો…',
    back: '← બધા ટૂલ્સ',
    noResults: 'તમારી શોધ સાથે કોઈ ટૂલ મળ્યું નથી.',
    catCalc: 'કૅલ્ક્યુલેટર',
    catUtil: 'રોજિંદા ઉપયોગી ટૂલ્સ',
    open: 'ટૂલ ખોલો',
    home: 'હોમ', tools: 'ટૂલ્સ', about: 'અમારા વિશે', contact: 'સંપર્ક કરો',
    privacy: 'ગોપનીયતા નીતિ', terms: 'શરતો', disclaimer: 'અસ્વીકરણ',
    dark: 'ડાર્ક મોડ', light: 'લાઇટ મોડ', language: 'ભાષા',
    note: 'ગણતરીઓ તમારા ડિવાઇસ પર થાય છે. તમે દાખલ કરેલી માહિતી અમારા સર્વર પર મોકલવામાં આવતી નથી.',
    copy: 'કૉપી કરો', copied: 'કૉપી થયું!',
    footer: 'મફત ટૂલ્સ, નોંધણી વિના.',
    notFoundTitle: 'પેજ મળ્યું નથી',
    notFoundText: 'આ પેજ અસ્તિત્વમાં નથી. ટૂલ્સની યાદી જુઓ.',
    directory: 'બધા મફત ટૂલ્સ',
  },
};

const Ctx = createContext(null);

export function LangProvider({ children }) {
  const [lang, setLang] = useState(() => {
    try { return localStorage.getItem('msl') || 'en'; } catch { return 'en'; }
  });

  useEffect(() => {
    document.documentElement.lang = lang;
    try { localStorage.setItem('msl', lang); } catch { /* storage unavailable */ }
  }, [lang]);

  return <Ctx.Provider value={{ lang, setLang, t: UI[lang] || UI.en }}>{children}</Ctx.Provider>;
}

export const useI18n = () => useContext(Ctx);
