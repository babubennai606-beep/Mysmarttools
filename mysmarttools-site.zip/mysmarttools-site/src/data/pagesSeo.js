// SEO metadata for non-tool routes. Used by the prerender script for crawlers and social previews.
// Keep these strings in sync with the page components in src/pages/.
export const PAGES_SEO = [
  {
    path: '/',
    title: 'MySmartTools – Free Online Calculators and Everyday Tools',
    description: 'Browse free online calculators and everyday tools: EMI, GST, BMI, age, percentage, image compressor, QR code and resume builder. No sign-up.',
  },
  {
    path: '/tools',
    title: 'All Free Tools | MySmartTools',
    description: 'Directory of all free MySmartTools: calculators, image tools, text tools, QR code generator and resume builder. No registration needed.',
  },
  {
    path: '/about',
    title: 'About MySmartTools – Free Online Tools for Everyday Use',
    description: 'Learn about MySmartTools, a free platform of calculators and everyday tools that run in your browser without registration.',
  },
  {
    path: '/contact',
    title: 'Contact MySmartTools – Questions, Feedback and Corrections',
    description: 'Contact the MySmartTools team with questions, feedback, corrections or partnership enquiries about our free online tools.',
  },
  {
    path: '/privacy',
    title: 'Privacy Policy – How MySmartTools Handles Your Data',
    description: 'Read how MySmartTools handles data, cookies, local storage and third-party advertising, including Google AdSense.',
  },
  {
    path: '/terms',
    title: 'Terms and Conditions – MySmartTools Free Tools',
    description: 'Terms of use for MySmartTools free online calculators and tools, including acceptable use and limitations of liability.',
  },
  {
    path: '/disclaimer',
    title: 'Disclaimer – Estimates for General Information Only | MySmartTools',
    description: 'MySmartTools calculators give general estimates only. They are not financial, tax, legal or medical advice.',
  },
];
