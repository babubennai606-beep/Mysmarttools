import { useState } from 'react';
import { Panel } from './shared.jsx';

const EMPTY = {
  name: '', role: '', email: '', phone: '', location: '',
  summary: '', experience: '', education: '', skills: '',
};

const lines = (s) => s.split('\n').map((x) => x.trim()).filter(Boolean);

export function ResumeBuilder() {
  const [d, setD] = useState(EMPTY);
  const set = (k) => (e) => setD({ ...d, [k]: e.target.value });
  const skills = d.skills.split(',').map((x) => x.trim()).filter(Boolean);

  return (
    <>
      <div className="no-print"><Panel>
        <div className="row">
          <label>Full name<input value={d.name} onChange={set('name')} autoComplete="name" /></label>
          <label>Job title<input value={d.role} onChange={set('role')} /></label>
          <label>Email<input type="email" value={d.email} onChange={set('email')} autoComplete="email" /></label>
          <label>Phone<input type="tel" value={d.phone} onChange={set('phone')} autoComplete="tel" /></label>
        </div>
        <label>Location<input value={d.location} onChange={set('location')} /></label>
        <label>Professional summary<textarea value={d.summary} onChange={set('summary')} /></label>
        <label>Experience (one role per line)<textarea value={d.experience} onChange={set('experience')} placeholder="Accountant, ABC Ltd, 2019–2024" /></label>
        <label>Education (one per line)<textarea value={d.education} onChange={set('education')} placeholder="B.Com, Gujarat University, 2018" /></label>
        <label>Skills (comma separated)<input value={d.skills} onChange={set('skills')} /></label>
        <div className="btn-row no-print">
          <button type="button" onClick={() => window.print()}>Print or save as PDF</button>
          <button type="button" className="ghost" onClick={() => setD(EMPTY)}>Clear form</button>
        </div>
        <p className="note no-print">Your resume is never uploaded. To save a PDF, choose “Save as PDF” as the printer destination.</p>
      </Panel></div>

      <article className="resume-preview" aria-label="Resume preview">
        <h2 className="resume-name">{d.name || 'Your Name'}</h2>
        {d.role && <p className="resume-role">{d.role}</p>}
        <p className="resume-contact">{[d.email, d.phone, d.location].filter(Boolean).join(' · ')}</p>
        {d.summary && <section><h3>Summary</h3><p>{d.summary}</p></section>}
        {lines(d.experience).length > 0 && <section><h3>Experience</h3><ul>{lines(d.experience).map((x, i) => <li key={i}>{x}</li>)}</ul></section>}
        {lines(d.education).length > 0 && <section><h3>Education</h3><ul>{lines(d.education).map((x, i) => <li key={i}>{x}</li>)}</ul></section>}
        {skills.length > 0 && <section><h3>Skills</h3><p>{skills.join(' · ')}</p></section>}
      </article>
    </>
  );
}
