import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Panel, Out } from './shared.jsx';

export function QrGenerator() {
  const [text, setText] = useState('https://www.example.com');
  const [src, setSrc] = useState('');
  const [err, setErr] = useState('');

  useEffect(() => {
    if (!text.trim()) { setSrc(''); setErr(''); return; }
    let live = true;
    QRCode.toDataURL(text, { width: 320, margin: 2, errorCorrectionLevel: 'M' })
      .then((url) => { if (live) { setSrc(url); setErr(''); } })
      .catch(() => { if (live) { setSrc(''); setErr('This text is too long for a QR code. Shorten it and try again.'); } });
    return () => { live = false; };
  }, [text]);

  return (
    <Panel>
      <label>Text or link
        <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a link or text" />
      </label>
      <Out>
        {src ? (
          <div className="qr">
            <img src={src} alt="QR code for the text you entered" width="260" height="260" />
            <div className="btn-row"><a className="button-link" href={src} download="qrcode.png">Download PNG</a></div>
          </div>
        ) : (err || 'Type something to create a QR code.')}
      </Out>
    </Panel>
  );
}
