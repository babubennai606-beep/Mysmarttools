// Shared helpers for tool components.
export function Panel({ children }) {
  return <div className="panel">{children}</div>;
}

export function Out({ children }) {
  return <div className="out" aria-live="polite">{children}</div>;
}

// Parse a number from user input. Returns NaN for empty or invalid values.
export const num = (v) => {
  const x = parseFloat(v);
  return Number.isFinite(x) ? x : NaN;
};

// Format numbers with Indian digit grouping and up to 2 decimals.
export const fmt = (x) => Number(x).toLocaleString('en-IN', { maximumFractionDigits: 2 });
