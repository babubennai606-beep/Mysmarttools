import { useState } from 'react';
import { Panel, Out, num, fmt } from './shared.jsx';

export function DiscountCalculator() {
  const [price, setPrice] = useState(2000);
  const [pct, setPct] = useState(15);
  const [original, setOriginal] = useState(2000);
  const [paid, setPaid] = useState(1700);

  const p = num(price), d = num(pct);
  let first = 'Enter a price and discount.';
  if (p >= 0 && d >= 0 && d <= 100) {
    const saved = (p * d) / 100;
    first = <>You save <b>₹{fmt(saved)}</b><br />Final price: <b>₹{fmt(p - saved)}</b></>;
  } else if (p >= 0 && d > 100) {
    first = 'Discount cannot be more than 100%.';
  }

  const o = num(original), q = num(paid);
  let second = 'Enter the original and final price.';
  if (o > 0 && q >= 0 && q <= o) {
    second = <>Discount: <b>{fmt(((o - q) / o) * 100)}%</b> · You save ₹{fmt(o - q)}</>;
  } else if (o > 0 && q > o) {
    second = 'The final price is higher than the original price.';
  }

  return (
    <>
      <Panel>
        <h2 style={{ marginTop: 0 }}>Find the final price</h2>
        <div className="row">
          <label>Original price (₹)<input type="number" min="0" value={price} onChange={(e) => setPrice(e.target.value)} /></label>
          <label>Discount (%)<input type="number" min="0" max="100" value={pct} onChange={(e) => setPct(e.target.value)} /></label>
        </div>
        <Out>{first}</Out>
      </Panel>
      <Panel>
        <h2 style={{ marginTop: 0 }}>Find the discount percentage</h2>
        <div className="row">
          <label>Original price (₹)<input type="number" min="0" value={original} onChange={(e) => setOriginal(e.target.value)} /></label>
          <label>Final price (₹)<input type="number" min="0" value={paid} onChange={(e) => setPaid(e.target.value)} /></label>
        </div>
        <Out>{second}</Out>
      </Panel>
    </>
  );
}
