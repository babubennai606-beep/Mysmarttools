import { useMemo, useState } from 'react';
import { Panel, Out } from './shared.jsx';

export function WordCounter() {
  const [text, setText] = useState('');
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const sentences = (text.match(/[.!?]+/g) || []).length;
  const minutes = Math.max(words ? 1 : 0, Math.ceil(words / 200));
  return (
    <Panel>
      <label>Your text
        <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Paste or type text here" />
      </label>
      <Out>
        Words: <b>{words}</b> · Characters: {text.length} · Without spaces: {text.replace(/\s/g, '').length} · Sentences: {sentences} · Reading time: ~{minutes} min
      </Out>
    </Panel>
  );
}

const CASES = {
  upper: { label: 'UPPER', fn: (t) => t.toUpperCase() },
  lower: { label: 'lower', fn: (t) => t.toLowerCase() },
  title: { label: 'Title Case', fn: (t) => t.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()) },
  sentence: {
    label: 'Sentence case',
    fn: (t) => t.toLowerCase().replace(/(^\s*|[.!?]\s+)([a-z])/g, (_, a, b) => a + b.toUpperCase()),
  },
};

export function CaseConverter() {
  const [text, setText] = useState('');
  const [mode, setMode] = useState('upper');
  return (
    <Panel>
      <label>Your text
        <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Type or paste text" />
      </label>
      <div className="btn-row">
        {Object.entries(CASES).map(([key, c]) => (
          <button key={key} type="button" className={mode === key ? '' : 'ghost'} onClick={() => setMode(key)}>
            {c.label}
          </button>
        ))}
      </div>
      <Out>{text ? <span className="pre">{CASES[mode].fn(text)}</span> : 'Type some text, then pick a case.'}</Out>
    </Panel>
  );
}

export function PasswordGenerator() {
  const [length, setLength] = useState(16);
  const [opts, setOpts] = useState({ upper: true, lower: true, numbers: true, symbols: true });
  const [seed, setSeed] = useState(0);
  const [copied, setCopied] = useState(false);

  const password = useMemo(() => {
    let set = '';
    if (opts.upper) set += 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    if (opts.lower) set += 'abcdefghijkmnopqrstuvwxyz';
    if (opts.numbers) set += '23456789';
    if (opts.symbols) set += '!@#$%^&*-_=+?';
    if (!set) return '';
    const bytes = new Uint32Array(length);
    crypto.getRandomValues(bytes);
    let pw = '';
    for (const b of bytes) pw += set[b % set.length];
    return pw;
    // seed forces regeneration when the button is pressed
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [length, opts, seed]);

  const toggle = (k) => setOpts((o) => ({ ...o, [k]: !o[k] }));

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(password);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <Panel>
      <label>Length: <b>{length}</b>
        <input type="range" min="8" max="40" value={length} onChange={(e) => setLength(Number(e.target.value))} />
      </label>
      <div className="check-row">
        {[['upper', 'Uppercase'], ['lower', 'Lowercase'], ['numbers', 'Numbers'], ['symbols', 'Symbols']].map(([k, label]) => (
          <label key={k}><input type="checkbox" checked={opts[k]} onChange={() => toggle(k)} /> {label}</label>
        ))}
      </div>
      <div className="btn-row">
        <button type="button" onClick={() => setSeed((s) => s + 1)}>Generate new password</button>
      </div>
      <Out>
        {password ? (
          <>
            <code>{password}</code>{' '}
            <button type="button" className="ghost" onClick={copy}>{copied ? 'Copied!' : 'Copy'}</button>
          </>
        ) : 'Select at least one character type.'}
      </Out>
    </Panel>
  );
}
