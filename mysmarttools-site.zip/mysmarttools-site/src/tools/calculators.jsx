import { useState } from 'react';
import { Panel, Out, num, fmt } from './shared.jsx';

export function AgeCalculator() {
  const [dob, setDob] = useState('');
  let result = 'Enter your date of birth.';
  if (dob) {
    const [Y, M, D] = dob.split('-').map(Number);
    const b = new Date(Y, M - 1, D);
    const now = new Date();
    if (b > now) {
      result = 'The date is in the future.';
    } else {
      let y = now.getFullYear() - b.getFullYear();
      let m = now.getMonth() - b.getMonth();
      let d = now.getDate() - b.getDate();
      if (d < 0) { m--; d += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
      if (m < 0) { y--; m += 12; }
      result = <><b>{y}</b> years, <b>{m}</b> months, <b>{d}</b> days old</>;
    }
  }
  return (
    <Panel>
      <label>Date of birth
        <input type="date" value={dob} onChange={(e) => setDob(e.target.value)} />
      </label>
      <Out>{result}</Out>
    </Panel>
  );
}

export function EmiCalculator() {
  const [principal, setPrincipal] = useState(500000);
  const [rate, setRate] = useState(8.5);
  const [years, setYears] = useState(5);
  const P = num(principal), R = num(rate) / 1200, N = num(years) * 12;
  let result = 'Enter a loan amount and tenure.';
  if (P > 0 && N > 0 && R >= 0) {
    const emi = R ? (P * R * Math.pow(1 + R, N)) / (Math.pow(1 + R, N) - 1) : P / N;
    const total = emi * N;
    result = <>Monthly EMI: <b>₹{fmt(emi)}</b><br />Total payable: ₹{fmt(total)}<br />Total interest: ₹{fmt(total - P)}</>;
  }
  return (
    <Panel>
      <div className="row">
        <label>Loan amount (₹)<input type="number" min="0" value={principal} onChange={(e) => setPrincipal(e.target.value)} /></label>
        <label>Annual interest (%)<input type="number" min="0" step="0.01" value={rate} onChange={(e) => setRate(e.target.value)} /></label>
      </div>
      <label>Tenure (years)<input type="number" min="1" value={years} onChange={(e) => setYears(e.target.value)} /></label>
      <Out>{result}</Out>
    </Panel>
  );
}

export function GstCalculator() {
  const [amount, setAmount] = useState(1000);
  const [gst, setGst] = useState(18);
  const [mode, setMode] = useState('add');
  const a = num(amount), g = num(gst);
  let result = 'Enter a valid amount.';
  if (a >= 0 && g >= 0) {
    let base, tax, total;
    if (mode === 'add') { base = a; tax = (a * g) / 100; total = a + tax; }
    else { total = a; base = a / (1 + g / 100); tax = a - base; }
    result = <>Net amount: ₹{fmt(base)}<br />GST ({g}%): ₹{fmt(tax)}<br />Total: <b>₹{fmt(total)}</b></>;
  }
  return (
    <Panel>
      <div className="row">
        <label>Amount (₹)<input type="number" min="0" value={amount} onChange={(e) => setAmount(e.target.value)} /></label>
        <label>GST rate (%)
          <select value={gst} onChange={(e) => setGst(e.target.value)}>
            <option value="5">5</option><option value="12">12</option><option value="18">18</option><option value="28">28</option>
          </select>
        </label>
      </div>
      <label>Mode
        <select value={mode} onChange={(e) => setMode(e.target.value)}>
          <option value="add">Add GST to amount</option>
          <option value="remove">Remove GST from amount</option>
        </select>
      </label>
      <Out>{result}</Out>
    </Panel>
  );
}

export function PercentageCalculator() {
  const [x, setX] = useState(20);
  const [y, setY] = useState(500);
  const [a, setA] = useState(30);
  const [b, setB] = useState(120);
  const parts = [`${num(x) || 0}% of ${num(y) || 0} = `];
  const first = num(x) * num(y) / 100;
  const second = num(b) ? (num(a) / num(b)) * 100 : NaN;
  return (
    <Panel>
      <div className="row">
        <label>Percent (%)<input type="number" value={x} onChange={(e) => setX(e.target.value)} /></label>
        <label>of number<input type="number" value={y} onChange={(e) => setY(e.target.value)} /></label>
      </div>
      <div className="row">
        <label>Number A<input type="number" value={a} onChange={(e) => setA(e.target.value)} /></label>
        <label>is what percent of B<input type="number" value={b} onChange={(e) => setB(e.target.value)} /></label>
      </div>
      <Out>
        {Number.isFinite(first) && <>{parts[0]}<b>{fmt(first)}</b></>}
        {Number.isFinite(second) && <><br />{num(a)} is <b>{fmt(second)}%</b> of {num(b)}</>}
      </Out>
    </Panel>
  );
}

export function BmiCalculator() {
  const [weight, setWeight] = useState(70);
  const [height, setHeight] = useState(170);
  const w = num(weight), h = num(height) / 100;
  let result = 'Enter a valid weight and height.';
  if (w > 0 && h > 0) {
    const bmi = w / (h * h);
    const cat = bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal weight' : bmi < 30 ? 'Overweight' : 'Obese';
    result = <>BMI: <b>{fmt(bmi)}</b> ({cat})<br /><small>General adult guide only. It does not account for muscle, age or health conditions.</small></>;
  }
  return (
    <Panel>
      <div className="row">
        <label>Weight (kg)<input type="number" min="1" value={weight} onChange={(e) => setWeight(e.target.value)} /></label>
        <label>Height (cm)<input type="number" min="1" value={height} onChange={(e) => setHeight(e.target.value)} /></label>
      </div>
      <Out>{result}</Out>
    </Panel>
  );
}
