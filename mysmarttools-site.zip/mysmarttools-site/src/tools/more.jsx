import { useEffect, useState } from 'react';
import { Panel, Out, num, fmt } from './shared.jsx';

export function SimpleInterestCalculator() {
  const [p, setP] = useState(100000);
  const [r, setR] = useState(7);
  const [t, setT] = useState(3);
  const P = num(p), R = num(r), T = num(t);
  let result = 'Enter principal, rate and time.';
  if (P >= 0 && R >= 0 && T >= 0) {
    const si = (P * R * T) / 100;
    result = <>Simple interest: <b>₹{fmt(si)}</b><br />Total amount: ₹{fmt(P + si)}</>;
  }
  return (
    <Panel>
      <label>Principal (₹)<input type="number" min="0" value={p} onChange={(e) => setP(e.target.value)} /></label>
      <div className="row">
        <label>Rate per year (%)<input type="number" min="0" step="0.01" value={r} onChange={(e) => setR(e.target.value)} /></label>
        <label>Time (years)<input type="number" min="0" step="0.01" value={t} onChange={(e) => setT(e.target.value)} /></label>
      </div>
      <Out>{result}</Out>
    </Panel>
  );
}

export function CompoundInterestCalculator() {
  const [p, setP] = useState(100000);
  const [r, setR] = useState(7);
  const [t, setT] = useState(5);
  const [n, setN] = useState(12);
  const P = num(p), R = num(r) / 100, T = num(t), N = num(n);
  let result = 'Enter principal, rate and time.';
  if (P >= 0 && R >= 0 && T >= 0 && N > 0) {
    const amount = P * Math.pow(1 + R / N, N * T);
    result = <>Final amount: <b>₹{fmt(amount)}</b><br />Interest earned: ₹{fmt(amount - P)}</>;
  }
  return (
    <Panel>
      <label>Principal (₹)<input type="number" min="0" value={p} onChange={(e) => setP(e.target.value)} /></label>
      <div className="row">
        <label>Annual rate (%)<input type="number" min="0" step="0.01" value={r} onChange={(e) => setR(e.target.value)} /></label>
        <label>Time (years)<input type="number" min="0" step="0.01" value={t} onChange={(e) => setT(e.target.value)} /></label>
      </div>
      <label>Compounding per year
        <select value={n} onChange={(e) => setN(e.target.value)}>
          <option value="1">Yearly (1)</option><option value="2">Half-yearly (2)</option>
          <option value="4">Quarterly (4)</option><option value="12">Monthly (12)</option><option value="365">Daily (365)</option>
        </select>
      </label>
      <Out>{result}</Out>
    </Panel>
  );
}

const LENGTH = { m: 1, km: 1000, cm: 0.01, mm: 0.001, ft: 0.3048, in: 0.0254, mi: 1609.344 };
const WEIGHT = { kg: 1, g: 0.001, lb: 0.45359237, oz: 0.0283495231 };
const TEMP = ['C', 'F', 'K'];

function toCelsius(v, u) {
  if (u === 'F') return ((v - 32) * 5) / 9;
  if (u === 'K') return v - 273.15;
  return v;
}
function fromCelsius(c, u) {
  if (u === 'F') return (c * 9) / 5 + 32;
  if (u === 'K') return c + 273.15;
  return c;
}

export function UnitConverter() {
  const [kind, setKind] = useState('length');
  const units = kind === 'length' ? Object.keys(LENGTH) : kind === 'weight' ? Object.keys(WEIGHT) : TEMP;
  const [from, setFrom] = useState('m');
  const [to, setTo] = useState('ft');
  const [value, setValue] = useState(1);

  const changeKind = (k) => {
    setKind(k);
    const list = k === 'length' ? Object.keys(LENGTH) : k === 'weight' ? Object.keys(WEIGHT) : TEMP;
    setFrom(list[0]);
    setTo(list[1]);
  };

  const v = num(value);
  let result = 'Enter a number.';
  if (Number.isFinite(v)) {
    let out;
    if (kind === 'temperature') out = fromCelsius(toCelsius(v, from), to);
    else {
      const table = kind === 'length' ? LENGTH : WEIGHT;
      out = (v * table[from]) / table[to];
    }
    result = <><b>{fmt(v)} {from}</b> = <b>{Number(out.toPrecision(8)).toLocaleString('en-IN')} {to}</b></>;
  }

  return (
    <Panel>
      <label>Category
        <select value={kind} onChange={(e) => changeKind(e.target.value)}>
          <option value="length">Length</option><option value="weight">Weight</option><option value="temperature">Temperature</option>
        </select>
      </label>
      <label>Value<input type="number" value={value} onChange={(e) => setValue(e.target.value)} /></label>
      <div className="row">
        <label>From
          <select value={from} onChange={(e) => setFrom(e.target.value)}>{units.map((u) => <option key={u}>{u}</option>)}</select>
        </label>
        <label>To
          <select value={to} onChange={(e) => setTo(e.target.value)}>{units.map((u) => <option key={u}>{u}</option>)}</select>
        </label>
      </div>
      <Out>{result}</Out>
    </Panel>
  );
}

const DAY = 86400000;
const toUTC = (s) => { const [y, m, d] = s.split('-').map(Number); return Date.UTC(y, m - 1, d); };

export function DateCalculator() {
  const today = new Date().toISOString().slice(0, 10);
  const [start, setStart] = useState(today);
  const [end, setEnd] = useState(today);
  const [base, setBase] = useState(today);
  const [days, setDays] = useState(30);

  let diffOut = 'Pick two dates.';
  if (start && end) {
    const d = Math.round((toUTC(end) - toUTC(start)) / DAY);
    const abs = Math.abs(d);
    diffOut = <><b>{abs}</b> days ({Math.floor(abs / 7)} weeks and {abs % 7} days){d < 0 ? ' · end date is before start date' : ''}</>;
  }

  let addOut = 'Pick a start date and enter days.';
  const n = num(days);
  if (base && Number.isFinite(n)) {
    const d = new Date(toUTC(base) + n * DAY);
    addOut = <>Result: <b>{d.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' })}</b></>;
  }

  return (
    <>
      <Panel>
        <h2 style={{ marginTop: 0 }}>Days between two dates</h2>
        <div className="row">
          <label>Start date<input type="date" value={start} onChange={(e) => setStart(e.target.value)} /></label>
          <label>End date<input type="date" value={end} onChange={(e) => setEnd(e.target.value)} /></label>
        </div>
        <Out>{diffOut}</Out>
      </Panel>
      <Panel>
        <h2 style={{ marginTop: 0 }}>Add or subtract days</h2>
        <div className="row">
          <label>Start date<input type="date" value={base} onChange={(e) => setBase(e.target.value)} /></label>
          <label>Days (negative to subtract)<input type="number" value={days} onChange={(e) => setDays(e.target.value)} /></label>
        </div>
        <Out>{addOut}</Out>
      </Panel>
    </>
  );
}

const toMin = (s) => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
const fmtMin = (m) => `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, '0')} min`;

export function TimeCalculator() {
  const [start, setStart] = useState('09:00');
  const [end, setEnd] = useState('17:30');
  const [base, setBase] = useState('10:15');
  const [hours, setHours] = useState(2);
  const [mins, setMins] = useState(45);

  let diffOut = 'Enter two times.';
  if (start && end) {
    const d = (toMin(end) - toMin(start) + 1440) % 1440;
    diffOut = <>Duration: <b>{fmtMin(d)}</b>{toMin(end) < toMin(start) ? ' (crosses midnight)' : ''}</>;
  }

  let addOut = 'Enter a time and a duration.';
  const add = num(hours) * 60 + num(mins);
  if (base && Number.isFinite(add)) {
    const total = (((toMin(base) + add) % 1440) + 1440) % 1440;
    const hh = String(Math.floor(total / 60)).padStart(2, '0'), mm = String(total % 60).padStart(2, '0');
    addOut = <>Result time: <b>{hh}:{mm}</b></>;
  }

  return (
    <>
      <Panel>
        <h2 style={{ marginTop: 0 }}>Time between two times</h2>
        <div className="row">
          <label>Start time<input type="time" value={start} onChange={(e) => setStart(e.target.value)} /></label>
          <label>End time<input type="time" value={end} onChange={(e) => setEnd(e.target.value)} /></label>
        </div>
        <Out>{diffOut}</Out>
      </Panel>
      <Panel>
        <h2 style={{ marginTop: 0 }}>Add a duration to a time</h2>
        <label>Start time<input type="time" value={base} onChange={(e) => setBase(e.target.value)} /></label>
        <div className="row">
          <label>Hours<input type="number" min="0" value={hours} onChange={(e) => setHours(e.target.value)} /></label>
          <label>Minutes<input type="number" min="0" value={mins} onChange={(e) => setMins(e.target.value)} /></label>
        </div>
        <Out>{addOut}</Out>
      </Panel>
    </>
  );
}

export function TextToSpeech() {
  const supported = typeof window !== 'undefined' && 'speechSynthesis' in window;
  const [text, setText] = useState('');
  const [rate, setRate] = useState(1);
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => () => { if (supported) window.speechSynthesis.cancel(); }, [supported]);

  const speak = () => {
    if (!supported || !text.trim()) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = rate;
    u.onend = () => setSpeaking(false);
    u.onerror = () => setSpeaking(false);
    setSpeaking(true);
    window.speechSynthesis.speak(u);
  };
  const stop = () => { if (supported) window.speechSynthesis.cancel(); setSpeaking(false); };

  if (!supported) {
    return <Panel><Out>Your browser does not support text to speech. Try a current version of Chrome, Edge, Safari or Firefox.</Out></Panel>;
  }
  return (
    <Panel>
      <label>Text to read aloud
        <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Type or paste text" />
      </label>
      <label>Speed: <b>{rate.toFixed(1)}×</b>
        <input type="range" min="0.5" max="2" step="0.1" value={rate} onChange={(e) => setRate(Number(e.target.value))} />
      </label>
      <div className="btn-row">
        <button type="button" onClick={speak} disabled={!text.trim()}>Speak</button>
        <button type="button" className="ghost" onClick={stop} disabled={!speaking}>Stop</button>
      </div>
      <Out>{speaking ? 'Speaking…' : 'Uses the voices installed on your device. Nothing is sent to a server.'}</Out>
    </Panel>
  );
}
