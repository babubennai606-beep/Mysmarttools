import { useEffect, useMemo, useState } from 'react';
import { Panel, Out, num } from './shared.jsx';

const ACCEPT = 'image/jpeg,image/png,image/webp';
const kb = (b) => (b / 1024).toFixed(1) + ' KB';

// Loads a chosen file into an <img>. Everything stays on the device.
function useImage() {
  const [file, setFile] = useState(null);
  const [img, setImg] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    setImg(null);
    setError('');
    if (!file) return;
    if (!file.type.startsWith('image/')) { setError('Please choose a JPG, PNG or WEBP image.'); return; }
    const url = URL.createObjectURL(file);
    const i = new Image();
    i.onload = () => setImg(i);
    i.onerror = () => setError('This image could not be read. Try a different file.');
    i.src = url;
    return () => URL.revokeObjectURL(url);
  }, [file]);
  return { file, setFile, img, error };
}

// Draws the image on a canvas and encodes it. JPEG gets a white background for transparent pixels.
function renderBlob(img, w, h, type, quality) {
  return new Promise((resolve, reject) => {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    if (type === 'image/jpeg') { ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, w, h); }
    ctx.drawImage(img, 0, 0, w, h);
    c.toBlob((b) => (b ? resolve(b) : reject(new Error('Your browser could not encode this format.'))), type, quality);
  });
}

function useRendered(img, w, h, type, quality) {
  const [state, setState] = useState({ blob: null, busy: false, err: '' });
  useEffect(() => {
    if (!img || !(w > 0 && h > 0)) { setState({ blob: null, busy: false, err: '' }); return; }
    let live = true;
    setState((s) => ({ ...s, busy: true }));
    renderBlob(img, w, h, type, quality)
      .then((blob) => live && setState({ blob, busy: false, err: '' }))
      .catch((e) => live && setState({ blob: null, busy: false, err: e.message }));
    return () => { live = false; };
  }, [img, w, h, type, quality]);
  return state;
}

function FilePick({ onPick }) {
  return (
    <label>Choose an image (JPG, PNG or WEBP)
      <input type="file" accept={ACCEPT} onChange={(e) => onPick(e.target.files?.[0] || null)} />
    </label>
  );
}

function Download({ blob, name }) {
  const href = useMemo(() => URL.createObjectURL(blob), [blob]);
  useEffect(() => () => URL.revokeObjectURL(href), [href]);
  return <a className="button-link" href={href} download={name}>Download</a>;
}

const extFor = (type) => (type === 'image/jpeg' ? 'jpg' : type === 'image/png' ? 'png' : 'webp');

export function ImageCompressor() {
  const { file, setFile, img, error } = useImage();
  const [quality, setQuality] = useState(0.7);
  const type = 'image/jpeg';
  const w = img ? img.naturalWidth : 0, h = img ? img.naturalHeight : 0;
  const { blob, busy, err } = useRendered(img, w, h, type, quality);

  let body = 'Choose an image to compress. Processing happens on your device.';
  if (error || err) body = error || err;
  else if (busy) body = 'Compressing…';
  else if (blob && file) {
    const saved = Math.round((1 - blob.size / file.size) * 100);
    body = (
      <>
        Original: {kb(file.size)} · Compressed: <b>{kb(blob.size)}</b>
        {saved > 0 ? <> · saved <b>{saved}%</b></> : <> · larger than the original; try a lower quality</>}
        <div className="btn-row"><Download blob={blob} name={`compressed.${extFor(type)}`} /></div>
      </>
    );
  }

  return (
    <Panel>
      <FilePick onPick={setFile} />
      <label>Quality: <b>{Math.round(quality * 100)}%</b>
        <input type="range" min="0.1" max="1" step="0.05" value={quality} onChange={(e) => setQuality(Number(e.target.value))} />
      </label>
      <p className="note">Output is JPEG. Lower quality means a smaller file with more visible artefacts.</p>
      <Out>{body}</Out>
    </Panel>
  );
}

export function ImageResizer() {
  const { file, setFile, img, error } = useImage();
  const [w, setW] = useState(0);
  const [h, setH] = useState(0);
  const [lock, setLock] = useState(true);
  const [type, setType] = useState('image/jpeg');
  const ratio = img ? img.naturalWidth / img.naturalHeight : 1;

  useEffect(() => {
    if (img) { setW(img.naturalWidth); setH(img.naturalHeight); }
  }, [img]);

  const onW = (v) => {
    const nw = Math.round(num(v));
    setW(nw);
    if (lock && nw > 0) setH(Math.round(nw / ratio));
  };
  const onH = (v) => {
    const nh = Math.round(num(v));
    setH(nh);
    if (lock && nh > 0) setW(Math.round(nh * ratio));
  };

  const valid = w > 0 && h > 0 && w <= 10000 && h <= 10000;
  const { blob, busy, err } = useRendered(img, valid ? w : 0, valid ? h : 0, type, 0.92);

  let body = 'Choose an image to resize. Processing happens on your device.';
  if (error || err) body = error || err;
  else if (!valid && img) body = 'Enter a width and height between 1 and 10000 pixels.';
  else if (busy) body = 'Resizing…';
  else if (blob) body = (<>New size: <b>{w} × {h} px</b> · {kb(blob.size)}<div className="btn-row"><Download blob={blob} name={`resized-${w}x${h}.${extFor(type)}`} /></div></>);

  return (
    <Panel>
      <FilePick onPick={setFile} />
      {img && (
        <>
          <div className="row">
            <label>Width (px)<input type="number" min="1" value={w} onChange={(e) => onW(e.target.value)} /></label>
            <label>Height (px)<input type="number" min="1" value={h} onChange={(e) => onH(e.target.value)} /></label>
          </div>
          <label className="check"><input type="checkbox" checked={lock} onChange={() => setLock(!lock)} /> Keep aspect ratio</label>
          <label>Output format
            <select value={type} onChange={(e) => setType(e.target.value)}>
              <option value="image/jpeg">JPG</option><option value="image/png">PNG</option><option value="image/webp">WEBP</option>
            </select>
          </label>
        </>
      )}
      <Out>{body}</Out>
    </Panel>
  );
}

export function ImageConverter() {
  const { file, setFile, img, error } = useImage();
  const [type, setType] = useState('image/webp');
  const w = img ? img.naturalWidth : 0, h = img ? img.naturalHeight : 0;
  const { blob, busy, err } = useRendered(img, w, h, type, 0.92);
  const unsupported = blob && blob.type !== type;

  let body = 'Choose an image to convert. Processing happens on your device.';
  if (error || err) body = error || err;
  else if (busy) body = 'Converting…';
  else if (unsupported) body = 'Your browser cannot save this format. Choose JPG or PNG instead.';
  else if (blob) body = (<>Converted to <b>{extFor(type).toUpperCase()}</b> · {kb(blob.size)}<div className="btn-row"><Download blob={blob} name={`converted.${extFor(type)}`} /></div></>);

  return (
    <Panel>
      <FilePick onPick={setFile} />
      <label>Convert to
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="image/jpeg">JPG</option><option value="image/png">PNG</option><option value="image/webp">WEBP</option>
        </select>
      </label>
      <p className="note">Transparent areas become white when converting to JPG.</p>
      <Out>{body}</Out>
    </Panel>
  );
}
