import { AgeCalculator, EmiCalculator, GstCalculator, PercentageCalculator, BmiCalculator } from './calculators.jsx';
import { WordCounter, CaseConverter, PasswordGenerator } from './utilities.jsx';
import {
  SimpleInterestCalculator, CompoundInterestCalculator, UnitConverter,
  DateCalculator, TimeCalculator, TextToSpeech,
} from './more.jsx';
import { DiscountCalculator } from './discount.jsx';
import { ImageCompressor, ImageResizer, ImageConverter } from './images.jsx';
import { QrGenerator } from './qr.jsx';
import { ResumeBuilder } from './resume.jsx';

// Every slug here must also exist in src/data/tools.js (and vice versa).
export const TOOL_COMPONENTS = {
  'age-calculator': AgeCalculator,
  'emi-calculator': EmiCalculator,
  'gst-calculator': GstCalculator,
  'percentage-calculator': PercentageCalculator,
  'discount-calculator': DiscountCalculator,
  'simple-interest-calculator': SimpleInterestCalculator,
  'compound-interest-calculator': CompoundInterestCalculator,
  'bmi-calculator': BmiCalculator,
  'image-compressor': ImageCompressor,
  'image-resizer': ImageResizer,
  'image-converter': ImageConverter,
  'qr-code-generator': QrGenerator,
  'word-counter': WordCounter,
  'case-converter': CaseConverter,
  'password-generator': PasswordGenerator,
  'unit-converter': UnitConverter,
  'date-calculator': DateCalculator,
  'time-calculator': TimeCalculator,
  'text-to-speech': TextToSpeech,
  'resume-builder': ResumeBuilder,
};
