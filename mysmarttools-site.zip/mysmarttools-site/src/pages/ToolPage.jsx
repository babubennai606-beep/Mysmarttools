import { Link, useParams } from 'react-router-dom';
import { TOOLS } from '../data/tools.js';
import { TOOL_COMPONENTS } from '../tools/index.jsx';
import { useI18n } from '../i18n.jsx';
import Seo from '../components/Seo.jsx';
import AdSlot from '../components/AdSlot.jsx';
import NotFound from './NotFound.jsx';

export default function ToolPage() {
  const { slug } = useParams();
  const { lang, t } = useI18n();
  const tool = TOOLS.find((x) => x.slug === slug);
  const Component = tool && TOOL_COMPONENTS[slug];

  if (!tool || !Component) return <NotFound />;

  const name = tool.name[lang] || tool.name.en;
  const description = tool.description[lang] || tool.description.en;
  const related = TOOLS.filter((x) => x.category === tool.category && x.slug !== tool.slug).slice(0, 4);

  return (
    <article>
      <Seo title={tool.seoTitle} description={tool.seoDescription} path={`/tools/${tool.slug}`} />
      <Link className="crumb" to="/tools">{t.back}</Link>
      <h1>{name}</h1>
      <p className="lead">{description}</p>

      <Component />

      <p className="note">{t.note}</p>
      <AdSlot />

      {related.length > 0 && (
        <section className="related" aria-label="Related tools">
          <h2>{t.catUtil}</h2>
          <ul className="tool-list">
            {related.map((x) => (
              <li key={x.slug}><Link to={`/tools/${x.slug}`}>{x.name[lang] || x.name.en}</Link></li>
            ))}
          </ul>
        </section>
      )}
    </article>
  );
}
