import { Link } from 'react-router-dom';
import { useI18n } from '../i18n.jsx';
import Seo from '../components/Seo.jsx';

export default function NotFound() {
  const { t } = useI18n();
  return (
    <section>
      <Seo title="Page Not Found | MySmartTools" description="This page does not exist on MySmartTools." path="/404" />
      <h1>{t.notFoundTitle}</h1>
      <p className="lead">{t.notFoundText}</p>
      <Link to="/tools">{t.tools}</Link>
    </section>
  );
}
