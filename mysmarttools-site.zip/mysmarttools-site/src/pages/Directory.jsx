import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { TOOLS } from '../data/tools.js';
import { useI18n } from '../i18n.jsx';
import Seo from '../components/Seo.jsx';
import AdSlot from '../components/AdSlot.jsx';

export default function Directory() {
  const { lang, t } = useI18n();
  const [query, setQuery] = useState('');

  const groups = useMemo(() => {
    const q = query.trim().toLowerCase();
    const matches = TOOLS.filter((tool) => {
      if (!q) return true;
      const haystack = `${tool.name.en} ${tool.name.hi} ${tool.name.gu} ${tool.slug}`.toLowerCase();
      return haystack.includes(q);
    });
    return [
      { key: 'calc', label: t.catCalc, items: matches.filter((x) => x.category === 'calc') },
      { key: 'util', label: t.catUtil, items: matches.filter((x) => x.category === 'util') },
    ].filter((g) => g.items.length);
  }, [query, t]);

  return (
    <>
      <Seo
        title="MySmartTools – Free Online Calculators and Everyday Tools"
        description="Browse free online calculators and everyday tools: EMI, GST, BMI, age, percentage, word counter, case converter and password generator. No sign-up."
        path="/"
      />
      <section className="hero">
        <h1>MySmartTools</h1>
        <p className="lead">{t.tagline}</p>
        <label className="visually-hidden" htmlFor="tool-search">{t.search}</label>
        <input
          id="tool-search"
          type="search"
          className="search"
          placeholder={t.search}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoComplete="off"
        />
      </section>

      {groups.length === 0 && <p className="lead">{t.noResults}</p>}

      {groups.map((g) => (
        <section key={g.key} className="category" aria-labelledby={`cat-${g.key}`}>
          <h2 id={`cat-${g.key}`}>{g.label}</h2>
          <ul className="tool-list">
            {g.items.map((tool) => (
              <li key={tool.slug}>
                <Link to={`/tools/${tool.slug}`}>
                  <span>
                    <strong>{tool.name[lang] || tool.name.en}</strong>
                    <small>{tool.description[lang] || tool.description.en}</small>
                  </span>
                  <span className="open">{t.open}</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ))}

      <AdSlot />
    </>
  );
}
