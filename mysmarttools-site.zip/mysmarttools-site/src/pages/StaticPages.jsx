import Seo from '../components/Seo.jsx';

const EMAIL = import.meta.env.VITE_CONTACT_EMAIL || 'your-email@yourdomain.com';
const SITE_URL = import.meta.env.VITE_SITE_URL || 'https://www.yourdomain.com';
const UPDATED = 'November 2026';

function Page({ title, seoTitle, seoDescription, path, children }) {
  return (
    <article className="prose">
      <Seo title={seoTitle} description={seoDescription} path={path} />
      <h1>{title}</h1>
      {children}
    </article>
  );
}

export function About() {
  return (
    <Page
      title="About Us"
      seoTitle="About MySmartTools – Free Online Tools for Everyday Use"
      seoDescription="Learn about MySmartTools, a free platform of calculators and everyday tools that run in your browser without registration."
      path="/about"
    >
      <p>MySmartTools is a free collection of practical online tools. It includes calculators for loans, GST, BMI, age and percentages, along with text tools and a password generator.</p>
      <p>We built the site so anyone can get a quick, accurate answer without creating an account or paying a fee. Most tools run entirely in your browser, so the information you type stays on your device.</p>
      <p>We review our calculations and descriptions and update them when rules or standards change. If you find an error, please contact us.</p>
    </Page>
  );
}

export function Contact() {
  return (
    <Page
      title="Contact Us"
      seoTitle="Contact MySmartTools – Questions, Feedback and Corrections"
      seoDescription="Contact the MySmartTools team with questions, feedback, corrections or partnership enquiries about our free online tools."
      path="/contact"
    >
      <p>For questions, feedback, bug reports or corrections, email us at <a href={`mailto:${EMAIL}`}>{EMAIL}</a>.</p>
      <p>We usually reply within three working days. Please do not send passwords or sensitive personal documents by email.</p>
    </Page>
  );
}

export function Privacy() {
  return (
    <Page
      title="Privacy Policy"
      seoTitle="Privacy Policy – How MySmartTools Handles Your Data"
      seoDescription="Read how MySmartTools handles data, cookies, local storage and third-party advertising, including Google AdSense."
      path="/privacy"
    >
      <p><em>Last updated: {UPDATED}</em></p>
      <h2>Data we process</h2>
      <p>Most tools process the values you enter directly in your browser. We do not store those values on our servers. The password generator creates passwords locally and does not send them anywhere.</p>
      <h2>Local storage</h2>
      <p>We save your chosen language and light or dark theme in your browser's local storage so your preferences persist. You can clear this at any time in your browser settings.</p>
      <h2>Cookies and advertising</h2>
      <p>We may display advertisements from third-party vendors, including Google. Google and its partners may use cookies to show ads based on your prior visits to this and other websites. You can opt out of personalised advertising through Google's Ads Settings, or visit www.aboutads.info.</p>
      <h2>Analytics</h2>
      <p>If we enable analytics, we will update this policy to say which provider is used and what it collects.</p>
      <h2>Children</h2>
      <p>The site is intended for general audiences and does not knowingly collect personal information from children under 13.</p>
      <h2>Your rights and contact</h2>
      <p>To ask questions about this policy or request removal of information you sent us by email, contact <a href={`mailto:${EMAIL}`}>{EMAIL}</a>.</p>
    </Page>
  );
}

export function Terms() {
  return (
    <Page
      title="Terms and Conditions"
      seoTitle="Terms and Conditions – MySmartTools Free Tools"
      seoDescription="Terms of use for MySmartTools free online calculators and tools, including acceptable use and limitations of liability."
      path="/terms"
    >
      <p><em>Last updated: {UPDATED}</em></p>
      <h2>Use of the site</h2>
      <p>The tools are provided free of charge for personal and general use. You agree not to misuse the site, attempt to disrupt it, or use it in ways that break applicable law.</p>
      <h2>No warranty</h2>
      <p>We try to keep results accurate, but the tools are provided "as is" without guarantees. Verify important results before relying on them.</p>
      <h2>Changes</h2>
      <p>We may change, add or remove features and update these terms at any time. Continued use after changes means you accept the revised terms.</p>
      <h2>Website address</h2>
      <p>This site is available at {SITE_URL}.</p>
      <h2>Contact</h2>
      <p>Questions about these terms: <a href={`mailto:${EMAIL}`}>{EMAIL}</a>.</p>
    </Page>
  );
}

export function Disclaimer() {
  return (
    <Page
      title="Disclaimer"
      seoTitle="Disclaimer – Estimates for General Information Only | MySmartTools"
      seoDescription="MySmartTools calculators give general estimates only. They are not financial, tax, legal or medical advice."
      path="/disclaimer"
    >
      <p>The calculators on MySmartTools give estimates for general information. EMI, GST, interest and BMI results are not financial, tax, legal or medical advice.</p>
      <p>Loan terms, GST rules and health guidelines can vary. Confirm important figures with your bank, a registered tax professional, or a qualified doctor before making decisions.</p>
      <p>BMI does not measure body fat or account for muscle mass, age, sex or health conditions. The site is provided as is, and we are not responsible for decisions made using its results.</p>
    </Page>
  );
}
